print "..\\..\\Debug\\disgen .\\dis.x\n";
system ("..\\..\\Debug\\disgen .\\dis.x");
system ("copy dis.h ..\\dis\\disp.h");



